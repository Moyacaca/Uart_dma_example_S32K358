/*
*   Copyright 2021 NXP
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be used strictly
*   in accordance with the applicable license terms.  By expressly accepting
*   such terms or by downloading, installing, activating and/or otherwise using
*   the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms.  If you do not agree to
*   be bound by the applicable license terms, then you may not retain,
*   install, activate or otherwise use the software.
*
*   This file contains sample code only. It is not part of the production code deliverables.
*/

/**
*   @file main.c
*
*   @addtogroup main_module main module documentation
*   @{
*/

/* User includes */
#include "Mcal.h"
#include "Clock_Ip.h"
#include "Dma_Ip.h"
#include "IntCtrl_Ip.h"
#include "Siul2_Port_Ip.h"
#include "Lpuart_Uart_Ip.h"

#include "string.h"

/* Welcome messages displayed at the console */
#define WELCOME_MSG_1 "Hello, This message is sent via Uart!\r\n"
#define WELCOME_MSG_2 "Have a nice day!\r\n"

/* Error message displayed at the console, in case data is received erroneously */
#define ERROR_MSG "An error occurred! The application will stop!\r\n"

/* Length of the message to be received from the console */
#define MSG_LEN  50U

/* Define channel */
#define UART_LPUART_INTERNAL_CHANNEL  13

volatile int exit_code = 0;

#define CMD_LEN 8
uint8_t gUart_Cmd_Buffer[2][CMD_LEN];
uint8_t gUart_Cmd_Buffer_Idx = 0;
uint8_t gUart_Cmd_Rx_Flag = 0;
uint8_t RX_Buffer[10];


/*!
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
    /* Write your code here */
    uint32_t remainingByte;
    volatile Lpuart_Uart_Ip_StatusType lpuartStatus = LPUART_UART_IP_STATUS_ERROR;

    OsIf_Init(NULL_PTR);

    // OsIf_Init(Null_PTR);
    /* Init clock  */
    Clock_Ip_Init(&Clock_Ip_aClockConfig[0]);

    /* Pins initialization */
    Siul2_Port_Ip_Init(NUM_OF_CONFIGURED_PINS_PortContainer_0_VS_0, g_pin_mux_InitConfigArr_PortContainer_0_VS_0);



    /* Interrupts controller initialization */
    IntCtrl_Ip_Init(&IntCtrlConfig_0);
    // IntCtrl_Ip_ConfigIrqRouting(&intRouteConfig);

    Dma_Ip_Init(&Dma_Ip_xDmaInitPB);
    Lpuart_Uart_Ip_Init(UART_LPUART_INTERNAL_CHANNEL, &Lpuart_Uart_Ip_xHwConfigPB_13_VS_0);

        /* Uart_AsyncSend transmit data */
        // lpuartStatus = Lpuart_Uart_Ip_AsyncSend(UART_LPUART_INTERNAL_CHANNEL, (const uint8 *)WELCOME_MSG_1, strlen(WELCOME_MSG_1));
        lpuartStatus = Lpuart_Uart_Ip_SyncSend(UART_LPUART_INTERNAL_CHANNEL, (uint8_t *)WELCOME_MSG_1, strlen(WELCOME_MSG_1),5000);

        // dmaStatus = dmaLogicChannel_InterruptCallback(NULL_PTR)
        do
        {
        	lpuartStatus = Lpuart_Uart_Ip_GetTransmitStatus(
        				UART_LPUART_INTERNAL_CHANNEL, &remainingByte);
        }
        while (LPUART_UART_IP_STATUS_BUSY == lpuartStatus);

        if (LPUART_UART_IP_STATUS_SUCCESS == lpuartStatus)
        {
        	Lpuart_Uart_Ip_SyncSend(UART_LPUART_INTERNAL_CHANNEL, (uint8_t *)"Transmit successfully through DMA\r\n", strlen("Transmit successfully through DMA\r\n"),5000);
            //return FALSE;
        }
//
//    	while(1)
//    	{
//    		/*receive 50 bytes from PC*/
//    		lpuartStatus = Lpuart_Uart_Ip_SyncReceive(UART_LPUART_INTERNAL_CHANNEL,RX_Buffer,50, 5000);
//    		// lpuartStatus = Lpuart_Uart_Ip_AsyncReceive(UART_LPUART_INTERNAL_CHANNEL,RX_Buffer,10);
//    		while(LPUART_UART_IP_STATUS_SUCCESS != lpuartStatus)
//    		{
//    			;
//    		}
//    		/*send what is received.*/
//    		lpuartStatus = Lpuart_Uart_Ip_SyncSend(UART_LPUART_INTERNAL_CHANNEL,RX_Buffer,50, 5000);
//    		while(LPUART_UART_IP_STATUS_SUCCESS != lpuartStatus)
//    		{
//    			;
//    		}
//
//    	}

    return exit_code;
}

/** @} */
